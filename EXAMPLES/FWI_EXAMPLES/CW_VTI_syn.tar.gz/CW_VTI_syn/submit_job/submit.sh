#!/bin/bash

echo 
echo '~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~'
echo
echo " source parameter file ..." 
source ./parameter

echo
echo '~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~'
echo
echo " Copy specfem executavles ..."
rm -rf bin
mkdir bin
cp -r $specfem_path/bin/* ./bin/

echo 
echo " create new job_info file ..."
rm -rf job_info
mkdir job_info

echo 
echo " create result file ..."
mkdir -p RESULTS

echo
echo '~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~'
echo
echo

workflow_DIR="$package_path/workflow"

#cp -r $initial_velocity_dir/*.bin ./DATA

if [ "$job" ==  "modeling" ] || [ "$job" ==  "Modeling" ]
then
    echo " ########################################################"
    echo " Forward modeling .." 
    echo " ########################################################"
    cp $workflow_DIR/Modeling_workstation.sh $Job_title.sh

elif [ "$job" ==  "kernel" ] || [ "$job" ==  "Kernel" ]
then
    echo " ########################################################"
    echo " Adjoint Inversion .." 
    echo " ########################################################"
#    cp $workflow_DIR/Kernel_pwy_source_attenuation.sh $Job_title.sh
    cp $workflow_DIR/Kernel_workstation.sh $Job_title.sh
    cp -r $initial_velocity_dir/*.bin ./DATA

elif [ "$job" ==  "inversion" ] || [ "$job" ==  "FWI" ]
then
    echo " ########################################################"
    echo " Adjoint Inversion .." 
    echo " ########################################################"
    cp $workflow_DIR/AdjointInversion_workstation.sh $Job_title.sh
    cp -r $initial_velocity_dir/*.bin ./DATA
else
    echo "Wrong job: $job"
fi

echo
echo " renew parameter file ..."
cp -r $package_path/SRC/seismo_parameters.f90 ./bin/
cp -r $package_path/SRC/seism_uti_module.f90 ./bin/
cp -r $package_path/SRC/corr_focus_mod.f90 ./bin/
cp -r $package_path/SRC/myMath_module.f90 ./bin/
cp -r $package_path/SRC/nrutil.f90 ./bin/
cp -r $package_path/SRC/nrtype.f90 ./bin/
cp -r $package_path/SRC/precision_module.f90 ./bin/
cp -r $package_path/SRC/myString_mod.f90 ./bin/

cp $package_path/scripts/renew_parameter.sh ./
bash ./renew_parameter.sh

echo 
echo " complile source codes ... "
rm -rf *.mod make_file
cp $package_path/make/make_$compiler ./make_file
cp $package_path/lib/constants.mod ./
FILE="make_file"
sed -e "s#^SRC_DIR=.*#SRC_DIR=$package_path/SRC#g"  $FILE > temp;  mv temp $FILE
make -f make_file clean
make -f make_file

echo 
echo " edit request nodes and tasks ..."
nproc=$NPROC_SPECFEM
nodes=$(echo $(echo "$ntasks $nproc $max_nproc_per_node" | awk '{ print $1*$2/$3 }') | awk '{printf("%d\n",$0+=$0<0?0:0.999)}')
echo " Request $nodes nodes, $ntasks tasks, $nproc cpus per task "

echo
echo '~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~'
echo

echo "submit job"
echo

export SUBMIT_DIR=$PWD

bash $Job_title.sh > ./job_info/output

echo
