#!/bin/bash

echo "running example: `date`"
echo "---------Generate true model structure files!---------"

currentdir=`pwd`

echo
echo "(will take about 1 minute)"
echo

# sets up directory structure in current example directoy
echo
echo "   setting up example..."
echo

mkdir -p OUTPUT_FILES
mkdir -p DATA


# links executables
rm -f xmeshfem2D xspecfem2D
ln -s $SeisElastic2D/specfem2d/bin/xmeshfem2D
ln -s $SeisElastic2D/specfem2d/bin/xspecfem2D

# stores setup
cp DATA/Par_file OUTPUT_FILES/
cp DATA/SOURCE OUTPUT_FILES/

cp -r ./DATA/Par_file_true_model ./DATA/Par_file

# Get the number of processors
NPROC=`grep nproc DATA/Par_file | cut -d = -f 2 | cut -d \# -f 1 | tr -d ' '`

# runs database generation
echo
echo "  running mesher..."
echo
./xmeshfem2D > mesh_output.txt

if [ "$NPROC" -eq 1 ]; then # This is a serial simulation
  echo
  echo " Running solver..."
  echo
  ./xspecfem2D
else # This is a MPI simulation
  echo
  echo " Running solver on $NPROC processors..."
  echo
  mpirun -np $NPROC ./xspecfem2D > specfem_output.txt
fi

# stores output
cp DATA/*SOURCE* DATA/*STATIONS* OUTPUT_FILES

mkdir model_true_bin

cp -r ./DATA/*.bin ./model_true_bin

rm -r ./DATA/*.bin

echo
echo "---------Forward modeling with true models finish!---------"
echo "see model results in directory: model_true_bin/"
echo
echo "ploting model"
python3 $VISUALIZE/plot_bin_kernel ./model_true_bin c33 8
echo "ploting data"
suoldtonew<./OUTPUT_FILES/Uz_file_single.su | suximage perc=99
date

echo "running example: `date`"
echo "---------Generate initial model structure files!---------"

currentdir=`pwd`

echo
echo "(will take about 1 minute)"
echo

# sets up directory structure in current example directoy
echo
echo "   setting up example..."
echo

mkdir -p OUTPUT_FILES
mkdir -p DATA

cp -r ./DATA/Par_file_initial_model ./DATA/Par_file

# links executables
rm -f xmeshfem2D xspecfem2D
ln -s $SeisElastic2D/specfem2d/bin/xmeshfem2D
ln -s $SeisElastic2D/specfem2d/bin/xspecfem2D

# stores setup
cp DATA/Par_file OUTPUT_FILES/
cp DATA/SOURCE OUTPUT_FILES/

# Get the number of processors
NPROC=`grep nproc DATA/Par_file | cut -d = -f 2 | cut -d \# -f 1 | tr -d ' '`

# runs database generation
echo
echo "  running mesher..."
echo
./xmeshfem2D > mesh_output.txt

if [ "$NPROC" -eq 1 ]; then # This is a serial simulation
  echo
  echo " Running solver..."
  echo
  ./xspecfem2D
else # This is a MPI simulation
  echo
  echo " Running solver on $NPROC processors..."
  echo
  mpirun -np $NPROC ./xspecfem2D > specfem_output.txt
fi

# stores output
cp DATA/*SOURCE* DATA/*STATIONS* OUTPUT_FILES

mkdir model_init_bin

cp -r ./DATA/*.bin ./model_init_bin

echo
echo "---------Forward modeling with initial models finish!---------"
echo "see model results in directory: model_init_bin/"
echo
rm -r ./DATA/*.bin

echo "ploting model"
python3 $VISUALIZE/plot_bin_kernel ./model_init_bin c33 8
echo "ploting data"
suoldtonew<./OUTPUT_FILES/Uz_file_single.su | suximage perc=99
date
date

